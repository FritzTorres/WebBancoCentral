namespace BancoCentralWeb.Models.Auth
{
    public class LogoutRequest
    {
        public Guid SessionId { get; set; }
    }
}